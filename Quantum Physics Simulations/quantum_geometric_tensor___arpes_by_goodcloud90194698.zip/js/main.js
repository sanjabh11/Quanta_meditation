import * as THREE from 'https://cdn.skypack.dev/three@0.132.2';
import { OrbitControls } from 'https://cdn.skypack.dev/three@0.132.2/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'https://cdn.skypack.dev/three@0.132.2/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'https://cdn.skypack.dev/three@0.132.2/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'https://cdn.skypack.dev/three@0.132.2/examples/jsm/postprocessing/UnrealBloomPass.js';

class QuantumVisualizer {
  constructor() {
    // Initialize parameters first
    this.params = {
      lightIntensity: 0.5,
      photonEnergy: 21,
      emissionAngle: 0,
      temperature: 300,
      latticeConstant: 1,
      visualization: 'all'
    };

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.init());
    } else {
      this.init();
    }
  }

  init() {
    this.setup();
    this.createScene();
    this.createPostProcessing();
    this.createLighting();
    this.createKagomeLattice();
    this.createWavefunction();
    this.createGeometricTensor();
    this.createARPES();
    this.setupGUI();
    this.addEventListeners();
    this.animate();
  }

  setup() {
    this.container = document.getElementById('container');
    
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.camera.position.set(0, 0, 30);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    
    this.clock = new THREE.Clock();

    // Add bloom effect
    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      1.5,
      0.4,
      0.85
    );
    this.bloomPass.threshold = 0;
    this.bloomPass.strength = 1.5;
    this.bloomPass.radius = 0;
  }

  createPostProcessing() {
    this.composer = new EffectComposer(this.renderer);
    const renderPass = new RenderPass(this.scene, this.camera);
    this.composer.addPass(renderPass);
    this.composer.addPass(this.bloomPass);
  }

  createScene() {
    this.scene.background = new THREE.Color(0x000000);
    this.scene.fog = new THREE.Fog(0x000000, 50, 100);
  }

  createLighting() {
    const ambientLight = new THREE.AmbientLight(0x404040);
    this.scene.add(ambientLight);

    this.mainLight = new THREE.DirectionalLight(0xffffff, 1);
    this.mainLight.position.set(10, 10, 10);
    this.scene.add(this.mainLight);
  }

  createKagomeLattice() {
    const geometry = new THREE.BufferGeometry();
    const vertices = [];
    const size = 10;
    const hexRadius = 1;

    // Create hexagonal kagome lattice
    for (let i = -size; i <= size; i++) {
      for (let j = -size; j <= size; j++) {
        const x = (i + (j % 2) * 0.5) * hexRadius * 3;
        const y = j * hexRadius * Math.sqrt(3);
        
        // Add vertices for triangles
        vertices.push(
          x, y, 0,
          x + hexRadius, y, 0,
          x + hexRadius/2, y + hexRadius * Math.sqrt(3)/2, 0
        );
      }
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    
    const material = new THREE.LineBasicMaterial({
      color: 0x4CAF50,
      transparent: true,
      opacity: 0.5
    });

    this.kagomeLattice = new THREE.LineSegments(geometry, material);
    this.scene.add(this.kagomeLattice);
  }

  createWavefunction() {
    // Enhanced wavefunction visualization
    const geometry = new THREE.IcosahedronGeometry(5, 3);
    const material = new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 },
        energy: { value: this.params.photonEnergy },
        temperature: { value: this.params.temperature }
      },
      vertexShader: `
        varying vec3 vNormal;
        varying vec3 vPosition;
        uniform float time;
        uniform float energy;
        
        void main() {
          vNormal = normal;
          vPosition = position;
          
          vec3 pos = position;
          float displacement = sin(time * 2.0 + position.x) * 
                             cos(time * 1.5 + position.y) * 
                             sin(time + position.z) * 0.3;
          
          pos += normal * displacement * (energy / 50.0);
          
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,
      fragmentShader: `
        uniform float time;
        uniform float temperature;
        varying vec3 vNormal;
        varying vec3 vPosition;
        
        void main() {
          vec3 baseColor = vec3(0.3, 0.6, 1.0);
          float temp = temperature / 300.0;
          
          float intensity = sin(vPosition.x * 2.0 + time) * 
                          cos(vPosition.y * 2.0 + time) * 
                          sin(vPosition.z * 2.0 + time);
          
          intensity = 0.5 + 0.5 * intensity;
          intensity *= temp;
          
          vec3 finalColor = mix(baseColor, vec3(1.0, 0.3, 0.1), temp - 1.0);
          
          gl_FragColor = vec4(finalColor * intensity, 0.6);
        }
      `,
      transparent: true,
      side: THREE.DoubleSide
    });

    this.wavefunction = new THREE.Mesh(geometry, material);
    this.scene.add(this.wavefunction);
  }

  createGeometricTensor() {
    const geometry = new THREE.PlaneGeometry(20, 20, 32, 32);
    const material = new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 }
      },
      vertexShader: `
        varying vec2 vUv;
        uniform float time;
        void main() {
          vUv = uv;
          vec3 pos = position;
          pos.z = sin(pos.x * 2.0 + time) * cos(pos.y * 2.0 + time) * 2.0;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        uniform float time;
        void main() {
          vec3 color = vec3(0.5 + 0.5 * sin(vUv.x * 10.0 + time),
                           0.5 + 0.5 * sin(vUv.y * 10.0 + time),
                           0.5);
          gl_FragColor = vec4(color, 0.3);
        }
      `,
      transparent: true,
      side: THREE.DoubleSide
    });

    this.geometricTensor = new THREE.Mesh(geometry, material);
    this.geometricTensor.rotation.x = -Math.PI / 2;
    this.scene.add(this.geometricTensor);
  }

  createARPES() {
    // Create photon beam
    const beamGeometry = new THREE.CylinderGeometry(0.1, 0.1, 20, 32);
    const beamMaterial = new THREE.MeshBasicMaterial({
      color: 0x00ffff,
      transparent: true,
      opacity: 0.3
    });
    this.photonBeam = new THREE.Mesh(beamGeometry, beamMaterial);
    this.photonBeam.rotation.x = Math.PI / 2;
    this.scene.add(this.photonBeam);

    // Create electron particles
    this.electrons = new THREE.Group();
    for (let i = 0; i < 50; i++) {
      const electronGeometry = new THREE.SphereGeometry(0.1, 16, 16);
      const electronMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
      const electron = new THREE.Mesh(electronGeometry, electronMaterial);
      this.electrons.add(electron);
    }
    this.scene.add(this.electrons);
  }

  updateARPES() {
    const time = this.clock.getElapsedTime();
    
    // Update electron positions
    this.electrons.children.forEach((electron, i) => {
      const t = (time + i * 0.1) % 5;
      electron.position.x = Math.sin(t * 2) * 10;
      electron.position.y = t * 2;
      electron.position.z = Math.cos(t * 2) * 10;
      electron.material.opacity = 1 - t/5;
    });
  }

  setupGUI() {
    const visualizationModes = ['all', 'wavefunction', 'lattice', 'arpes'];
    
    visualizationModes.forEach(mode => {
      const button = document.createElement('button');
      button.className = 'mode-button';
      button.textContent = mode.charAt(0).toUpperCase() + mode.slice(1);
      button.addEventListener('click', () => this.setVisualizationMode(mode));
      document.querySelector('.visualization-mode-switcher').appendChild(button);
    });
  }

  setVisualizationMode(mode) {
    this.params.visualization = mode;
    
    // Update visibility of different components
    this.wavefunction.visible = mode === 'all' || mode === 'wavefunction';
    this.kagomeLattice.visible = mode === 'all' || mode === 'lattice';
    this.electrons.visible = mode === 'all' || mode === 'arpes';
    
    // Update UI
    document.querySelectorAll('.mode-button').forEach(button => {
      button.classList.toggle('active', 
        button.textContent.toLowerCase() === mode);
    });
  }

  updateQuantumStats() {
    // Update real-time quantum statistics
    const energy = document.getElementById('energy-readout');
    const momentum = document.getElementById('momentum-readout');
    const temp = document.getElementById('temperature-readout');
    
    energy.textContent = `Energy: ${this.params.photonEnergy.toFixed(2)} eV`;
    momentum.textContent = `Momentum: ${(Math.sin(this.params.emissionAngle * Math.PI / 180) * 
      Math.sqrt(2 * this.params.photonEnergy)).toFixed(2)} Å⁻¹`;
    temp.textContent = `Temperature: ${this.params.temperature.toFixed(1)} K`;
  }

  updateMaterials(time) {
    this.wavefunction.material.uniforms.time.value = time;
    this.geometricTensor.material.uniforms.time.value = time;
    this.wavefunction.material.uniforms.energy.value = this.params.photonEnergy;
    this.wavefunction.material.uniforms.temperature.value = this.params.temperature;
  }

  addEventListeners() {
    window.addEventListener('resize', this.onWindowResize.bind(this));
    
    // Add touch event handling for mobile
    let touchStartY = 0;
    const controls = document.querySelector('.controls');
    const collapseButton = document.querySelector('.collapse-button');
    
    if (controls && collapseButton) {
      // Handle click/tap events
      collapseButton.addEventListener('click', (e) => {
        e.preventDefault();
        controls.classList.toggle('collapsed');
      });

      // Handle touch events for swipe
      controls.addEventListener('touchstart', (e) => {
        touchStartY = e.touches[0].clientY;
      }, { passive: true });

      controls.addEventListener('touchmove', (e) => {
        e.preventDefault();
        const touchY = e.touches[0].clientY;
        const diff = touchStartY - touchY;
        
        if (Math.abs(diff) > 50) { // Minimum swipe distance
          if (diff > 0) { // Swipe up
            controls.classList.remove('collapsed');
          } else { // Swipe down
            controls.classList.add('collapsed');
          }
        }
      });
    }

    // Update control panel parameters
    const updateParameter = (slider, valueDisplay) => {
      if (slider && valueDisplay) {
        const value = slider.value;
        const unit = slider.id === 'temperature' ? ' K' : 
                     slider.id === 'photon-energy' ? ' eV' : 
                     slider.id === 'emission-angle' ? '°' : '';
        valueDisplay.textContent = value + unit;
        
        // Update quantum visualizer parameters
        const paramName = slider.id.replace('-', '');
        if (this.params.hasOwnProperty(paramName)) {
          this.params[paramName] = parseFloat(value);
        }
      }
    };

    // Initialize all sliders
    document.querySelectorAll('input[type="range"]').forEach(slider => {
      const valueDisplay = slider.parentElement.querySelector('.parameter-value');
      // Set initial values
      updateParameter(slider, valueDisplay);
      
      // Add event listeners
      slider.addEventListener('input', () => {
        updateParameter(slider, valueDisplay);
      });

      // Add touch-specific event listeners for mobile
      slider.addEventListener('touchstart', (e) => {
        e.stopPropagation();
      }, { passive: true });
    });

    // Handle orientation change
    window.addEventListener('orientationchange', () => {
      setTimeout(this.onWindowResize.bind(this), 100);
    });
  }

  onWindowResize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.bloomPass.resolution = new THREE.Vector2(window.innerWidth, window.innerHeight);
  }

  animate() {
    requestAnimationFrame(this.animate.bind(this));
    
    const time = this.clock.getElapsedTime();

    // Update all materials and uniforms
    this.updateMaterials(time);
    this.updateARPES();
    this.updateQuantumStats();

    // Update controls
    this.controls.update();

    // Render with post-processing
    this.composer.render();
  }
}

// Initialize visualization when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  const quantumViz = new QuantumVisualizer();
  
  // Add collapse button functionality
  const controls = document.querySelector('.controls');
  const collapseButton = document.querySelector('.collapse-button');
  
  if (controls && collapseButton) {
    collapseButton.addEventListener('click', () => {
      controls.classList.toggle('collapsed');
    });
  }
  
  // Add slider update handlers
  document.querySelectorAll('input[type="range"]').forEach(slider => {
    const valueDisplay = slider.parentElement.querySelector('.parameter-value');
    if (valueDisplay) {
      slider.addEventListener('input', (e) => {
        const value = e.target.value;
        const unit = slider.id === 'temperature' ? ' K' : 
                     slider.id === 'photon-energy' ? ' eV' : 
                     slider.id === 'emission-angle' ? '°' : '';
        valueDisplay.textContent = value + unit;
        
        // Update quantum visualizer parameters
        if (quantumViz.params.hasOwnProperty(slider.id.replace('-', ''))) {
          quantumViz.params[slider.id.replace('-', '')] = parseFloat(value);
        }
      });
    }
  });
});